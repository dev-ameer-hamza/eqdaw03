package Modelo;

public class Liga {
    private String estado;

    public Liga(String estado){
        this.estado = estado;
    }

    public Liga() {
    }

    public String getEstado() {
        return estado;
    }


    public void setEstado(String estado) {
        this.estado = estado;
    }
}
